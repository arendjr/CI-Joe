#!/bin/sh

cd "$(dirname "$0")"
node app/slave.js "$@"
exit $?
