define(function() {
    return {};
});
