#!/bin/sh

cd "$(dirname "$0")"
node app/master.js
